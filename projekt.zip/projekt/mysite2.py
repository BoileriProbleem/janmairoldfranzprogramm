from flask import Flask, render_template, request, redirect, url_for
import re
from bs4 import BeautifulSoup
from urllib.request import urlopen

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def hello_world():
    #ei tööta


    def loeb_failist(failinimi):
        joogid = []
        with open(failinimi, "r", encoding="UTF-8") as fail:
            fail.readline()  
            while True:
                nimerida = fail.readline().strip()
                if not nimerida:
                    break  

                hinnarida = fail.readline().strip()

            
                jooginimi = re.search(r'"name": "(?=.*?[%]|.*?\bvol\b)(.*?)\s?(\d+(?:[,.]\d+)?\s?%?\s?(?:vol)?)\s*(\d+(?:[,.]\d+)?)(?:[lL]|ml)', nimerida, re.IGNORECASE)
                hinnasumma = re.search(r'"price": (\d+\.?\d*)', hinnarida)

                if jooginimi and hinnasumma:
                        nimi = jooginimi.group(1)  
                        etanool = float(jooginimi.group(2).replace(',', '.').strip('% vol').strip("% "))

                        # Check for "-pakk" and extract the quantity
                        match = re.search(r'(\d+)-pakk"', nimerida)
                        if match:
                            kogus = float(match.group(1)) * float(jooginimi.group(3).replace(',', '.'))
                        else:
                            kogus = float(jooginimi.group(3).replace(',', '.'))  

                        hind = float(hinnasumma.group(1))

                        joogid.append ({
                            "nimi": nimi,
                            "etanool": etanool,
                            "kogus": kogus,
                            "hind": hind
                        })

        return joogid
        
    min_etanool = 0
    max_etanool = 0
    min_kogus = 0
    max_kogus = 0
    min_hind = 0
    max_hind = 0
        
    if request.method == 'POST':
        min_etanool = request.form['minp']
        max_etanool = request.form['maxp']
        min_kogus = request.form['mink']
        max_kogus = request.form['maxk']
        min_hind = request.form['minh']
        max_hind = request.form['maxh']

    print(min_etanool)
    
    def parimjoogivalik(joogid, min_etanool, max_etanool, min_kogus, max_kogus, min_hind, max_hind):
        parim_jook = None
        parim_hind = float('inf')  

        for jook in joogid:
            if (float(min_etanool) <= jook["etanool"] <= float(max_etanool) and
                float(min_kogus) <= jook["kogus"] <= float(max_kogus) and
                float(min_hind) <= jook["hind"] <= float(max_hind)):
                etanooli_hind = etanooli_arvutus_hind(jook)  

                if etanooli_hind < parim_hind:  
                    parim_hind = etanooli_hind
                    parim_jook = jook

        return parim_jook

    def etanooli_arvutus_kogus(jook):
        etanooli_ml = (jook["etanool"] / 100) * jook["kogus"] * 1000  
        return etanooli_ml

    def etanooli_arvutus_hind(jook):
        etanooli_ml = etanooli_arvutus_kogus(jook)
        etanooli_hind_ml_suhtes = jook["hind"] / etanooli_ml
        return etanooli_hind_ml_suhtes
    
    tulemus = ""
    displayNimi = ""
    displayHind = ""
    displayEtanool = ""
    displayKogus = ""
    displayVäärtus = ""
    
    if __name__ == "__main__":
        joogid = loeb_failist("Lahja.txt")
        parim_jook = parimjoogivalik(joogid, min_etanool, max_etanool, min_kogus, max_kogus, min_hind, max_hind)

        if parim_jook:
            etanooli_hind = round(etanooli_arvutus_hind(parim_jook), 5)
            tulemus = "Leitud sobiv jook: "
            displayNimi = "Nimi: " + str(parim_jook["nimi"])
            displayHind = "Hind: " + str(parim_jook["hind"]) + "€"
            displayEtanool = "Etanooli protsent: " + str(parim_jook["etanool"]) + "%"
            displayKogus = "Kogus: " + str(parim_jook["kogus"]) + "L"
            displayVäärtus = "Etanooli hind 1ml kohta: " + str(etanooli_hind) + "€"
            print(f"Leitud sobiv jook:")
            print(f"Nimi: {parim_jook['nimi']}, Hind: {parim_jook['hind']} €, Etanool: {parim_jook['etanool']} %, Kogus: {parim_jook['kogus']} L")
            print(f"Etanooli hind (1ml kohta): {etanooli_hind:.4f} €")
        else:
            tulemus = "Ei leidnud sobivat jooki."
            print("Ei leidnud sobivat jooki.")
            
    return render_template('avaleht.html', Tulemus = tulemus, n = displayNimi, h = displayHind, e = displayEtanool, k = displayKogus, v = displayVäärtus)




@app.route('/rimi', methods=['GET', 'POST'])
def rimi():
    def andmesaak(test, kokku, eelmineväli, eelmine):
            olud = open("Olud.txt", "a", encoding="utf-8")
            kakskoos = ""
            for rida in test:
                if rida[0].isdigit():
                    if kokku == False:
                        kakskoos = eelmine + "," + rida
                        kokku = True
                    else:
                        olud.write(kakskoos + "," + rida)
                        kokku = False
                        eelmineväli = False
                elif eelmineväli:
                    if kakskoos.find(eelmine) != -1:
                        olud.write(kakskoos)
                    else:
                        olud.write(eelmine)
                    eelmineväli = False
                    kokku = False
                if rida.find("name") != -1 or rida.find("price") != -1:
                    eelmine = rida
                    eelmineväli = True
            olud.close()
            
    def leht(i):
        url = "https://www.rimi.ee/epood/ee/tooted/alkohol/c/SH-1?currentPage=" + str(i) + "&pageSize=80&query=%3Arelevance%3AallCategories%3ASH-1%3AassortmentStatus%3AinAssortment"
        page = urlopen(url)
        html = page.read().decode("utf-8")
        soup = BeautifulSoup(html, "html.parser")
        test = open("Test.txt", "w", encoding="utf-8")
        data = soup.find('script', type='text/plain').get_text()
        test.write(data)
        test.close()
        with open("Test.txt", "r", encoding='utf-8') as f:
                test = f.read()
        f.close()
        test = test.split(",")
        return test

    def tekst():
        with open("Olud.txt", "r", encoding="utf-8") as yeah:
            tekst = yeah.read().replace(r'\/', '/')
            tekst = tekst.replace("\u015b", "ś")
            decoded_tekst = tekst.encode('utf-8').decode('unicode-escape')
    
        with open("Lahja.txt", "w", encoding="utf-8") as lahja:
            lahja.write(decoded_tekst)
    
    

    i = 1
    olud = open("Olud.txt", "w", encoding="utf-8")
    olud.close()
    lru = "https://www.rimi.ee/epood/ee/tooted/alkohol/c/SH-1?currentPage=" + str(i) + "&pageSize=80&query=%3Arelevance%3AallCategories%3ASH-1%3AassortmentStatus%3AinAssortment"
    egap = urlopen(lru)
    lmth = egap.read().decode("utf-8")
    puos = BeautifulSoup(lmth, "html.parser")
    võhandu = open("Test.txt", "w", encoding="utf-8")
    pagination_items = puos.find_all('li', class_='pagination__item')
    numbriots = re.compile(r'\d+')
    esimene = True
    for rida in pagination_items:
        if '-chevron' in str(rida):
            if not esimene:
                number = numbriots.search(str(eelmine))
                if number:
                    maks = number.group()
            esimene = False
        eelmine = rida
    while i <= int(maks):
        tagastus = leht(i)
        i += 1
        Gojo = "jap"
        Filip = False
        Hamlet = False
        andmesaak(tagastus, Hamlet, Filip, Gojo)
    tekst()
    return render_template('rimi.html')